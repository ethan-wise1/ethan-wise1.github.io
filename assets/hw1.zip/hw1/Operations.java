package cs250.hw1;

public class Operations {
    public Operations() {
    }

    // Task two method
    public static String taskTwo(String p) {
        String type = "";
        if(p.contains("b")) {
            type = "Binary";
        }
        else if(p.contains("x")) {
            type = "Hexadecimal";
        }
        else {
            type = "Decimal";
        }
        return type;
    }

    // Task three method
    public static boolean errorChecker(String p, String n) {
        if(taskTwo(p) == "Decimal") {
            for(int i=0; i < n.length(); i++) {
                if(n.substring(i,i+1).matches("[a-zA-Z-?#/@&>/<]+")) {
                    if(n.equals(p)) {
                        System.out.println(n + "=false");
                        //System.exit(0);
                        return false;
                    }
                    else {
                        System.out.println(p + n + "=false");
                        //System.exit(0);
                        return false;
                    }
                }
            }
        }
        if(taskTwo(p) == "Binary") {
            for(int i=0; i < n.length(); i++) {
                if(n.substring(i, i+1).matches("[a-zA-Z2-9-?#/@&>/<]+")) {
                    System.out.println(p + n + "=false");
                    //System.exit(0);
                    return false;
                }
            }
        }
        if(taskTwo(p) == "Hexadecimal") {
            for(int i=0; i < n.length(); i++) {
                if(n.substring(i,i+1).matches("[g-zG-Z-?#/@&>/<]+")) {
                    System.out.println(p + n + "=false");
                    //System.exit(0);
                    return false;
                }
            }
        }
        // if ( (taskTwo(p) != "Decimal") || (taskTwo(p) != "Binary") || (taskTwo(p) != "Hexadecimal") ) {
        //     System.out.println(p + n + "=false");
        //     System.exit(0);
        // }
        return true;
    }

    // Convert to Decimal 
    public static String decimalConverter(String p, String n) {
        double decimal = 0;
        int base;
        String decimalS = "";
        if(taskTwo(p) == "Hexadecimal") {
            base = 16;
            for(int i = 1; i < n.length()+1; i++) {
                //System.out.println(n.substring(n.length()-i,n.length()-(i-1) ));
                switch (n.substring(n.length()-i, n.length()-(i-1))) {
                    case "0":
                    decimal = decimal + (Math.pow(base, i-1) * 0);
                    decimalS = String.valueOf((int) decimal);
                    break;
                    case "1":
                    decimal = decimal + (Math.pow(base, i-1) * 1);
                    decimalS = String.valueOf((int) decimal);
                    break;
                    case "2":
                    decimal = decimal + (Math.pow(base, i-1) * 2);
                    decimalS = String.valueOf((int) decimal);
                    break;
                    case "3":
                    decimal = decimal + (Math.pow(base, i-1) * 3);
                    decimalS = String.valueOf((int) decimal);
                    break;
                    case "4":
                    decimal = decimal + (Math.pow(base, i-1) * 4);
                    decimalS = String.valueOf((int) decimal);
                    break;
                    case "5":
                    decimal = decimal + (Math.pow(base, i-1) * 5);
                    decimalS = String.valueOf((int) decimal);
                    break;
                    case "6":
                    decimal = decimal + (Math.pow(base, i-1) * 6);
                    decimalS = String.valueOf((int) decimal);
                    break;
                    case "7":
                    decimal = decimal + (Math.pow(base, i-1) * 7);
                    decimalS = String.valueOf((int) decimal);
                    break;
                    case "8":
                    decimal = decimal + (Math.pow(base, i-1) * 8);
                    decimalS = String.valueOf((int) decimal);
                    break;
                    case "9":
                    decimal = decimal + (Math.pow(base, i-1) * 9);
                    decimalS = String.valueOf((int) decimal);
                    break;
                    case "a":
                    decimal = decimal + (Math.pow(base, i-1) * 10);
                    decimalS = String.valueOf((int) decimal);
                    break;
                    case "b":
                    decimal = decimal + (Math.pow(base, i-1) * 11);
                    decimalS = String.valueOf((int) decimal);
                    break;
                    case "c":
                    decimal = decimal + (Math.pow(base, i-1) * 12);
                    decimalS = String.valueOf((int) decimal);
                    break;
                    case "d":
                    decimal = decimal + (Math.pow(base, i-1) * 13);
                    decimalS = String.valueOf((int) decimal);
                    break;
                    case "e":
                    decimal = decimal + (Math.pow(base, i-1) * 14);
                    decimalS = String.valueOf((int) decimal);
                    break;
                    case "f":
                    decimal = decimal + (Math.pow(base, i-1) * 15);
                    decimalS = String.valueOf((int) decimal);
                    break;
                }
            }
        }
        else {
            base = 2;
            for(int i = 1; i < n.length()+1; i++) {
               // System.out.println(n.substring(n.length()-i,n.length()-(i-1) ));
                if(n.substring(n.length()-i, n.length()-(i-1)).equals("1")) {
                    decimal = decimal + Math.pow(base, i-1);
                    decimalS = String.valueOf((int) decimal);
                }
            }
        }
        return decimalS;
    }

    // Convert to Binary 
    public static String binaryConverter(String p, String n) {
        String binary = "";

        if(taskTwo(p) == "Hexadecimal") {
            for(int i = 1; i < n.length()+1; i++) {
                switch (n.substring(n.length()-i, n.length()-(i-1))) {
                    case "0":
                    binary = "0000".concat(binary);
                    break;
                    case "1":
                    binary = "0001".concat(binary);
                    break;
                    case "2":
                    binary = "0010".concat(binary);
                    break;
                    case "3":
                    binary = "0011".concat(binary);
                    break;
                    case "4":
                    binary = "0100".concat(binary);
                    break;
                    case "5":
                    binary = "0101".concat(binary);
                    break;
                    case "6":
                    binary = "0110".concat(binary);
                    break;
                    case "7":
                    binary = "0111".concat(binary);
                    break;
                    case "8":
                    binary = "1000".concat(binary);
                    break;
                    case "9":
                    binary = "1001".concat(binary);
                    break;
                    case "a":
                    binary = "1010".concat(binary);
                    break;
                    case "b":
                    binary = "1011".concat(binary);
                    break;
                    case "c":
                    binary = "1100".concat(binary);
                    break;
                    case "d":
                    binary = "1101".concat(binary);
                    break;
                    case "e":
                    binary = "1110".concat(binary);
                    break;
                    case "f":
                    binary = "1111".concat(binary);
                    break;
                }
            }
        }
        else {
            int decimal = 0;
            for(int i=1; i<n.length()+1; i++) {
                switch (n.substring(n.length()-i, n.length()-(i-1))) {
                    case "1":
                    decimal = decimal + (int) (Math.pow(10, i-1) * 1);
                    break;
                    case "2":
                    decimal = decimal + (int) (Math.pow(10, i-1) * 2);
                    break;
                    case "3":
                    decimal = decimal + (int) (Math.pow(10, i-1) * 3);
                    break;
                    case "4":
                    decimal = decimal + (int) (Math.pow(10, i-1) * 4);
                    break;
                    case "5":
                    decimal = decimal + (int) (Math.pow(10, i-1) * 5);
                    break;
                    case "6":
                    decimal = decimal + (int) (Math.pow(10, i-1) * 6);
                    break;
                    case "7":
                    decimal = decimal + (int) (Math.pow(10, i-1) * 7);
                    break;
                    case "8":
                    decimal = decimal + (int) (Math.pow(10, i-1) * 8);
                    break;
                    case "9":
                    decimal = decimal + (int) (Math.pow(10, i-1) * 9);
                    break;
            }
        }
            int remainder = decimal;
            while(remainder != 0) {
                if((decimal%2) == 1) {
                    binary = "1".concat(binary);
                    decimal = decimal / 2;
                    remainder = decimal;
                }
                else {
                    binary = "0".concat(binary);
                    decimal = decimal / 2;
                    remainder = decimal;
                }
            }
        }
        return binary;
    }

    // Convert to Hexadecimal
    public static String hexConverter(String p, String n) {
        String hexa = "";
        if(taskTwo(p) == "Binary") {
            int size = n.length();
            while(size%4 !=0) {
                n = "0".concat(n);
                size++;
            }
            for(int i = 4; i <= n.length(); i= i+4) {
                //System.out.println(n.substring(i-4, i));
                switch (n.substring(i-4, i)) {
                    case "0000":
                    hexa = hexa.concat("0");
                    break;
                    case "0001":
                    hexa = hexa.concat("1");
                    break;
                    case "0010":
                    hexa = hexa.concat("2");
                    break;
                    case "0011":
                    hexa = hexa.concat("3");
                    break;
                    case "0100":
                    hexa = hexa.concat("4");
                    break;
                    case "0101":
                    hexa = hexa.concat("5");
                    break;
                    case "0110":
                    hexa = hexa.concat("6");
                    break;
                    case "0111":
                    hexa = hexa.concat("7");
                    break;
                    case "1000":
                    hexa = hexa.concat("8");
                    break;
                    case "1001":
                    hexa = hexa.concat("9");
                    break;
                    case "1010":
                    hexa = hexa.concat("a");
                    break;
                    case "1011":
                    hexa = hexa.concat("b");
                    break;
                    case "1100":
                    hexa = hexa.concat("c");
                    break;
                    case "1101":
                    hexa = hexa.concat("d");
                    break;
                    case "1110":
                    hexa = hexa.concat("e");
                    break;
                    case "1111":
                    hexa = hexa.concat("f");
                    break;
                }
            }
        }
        // else {
        //     System.out.println(n);
        //     String decimal = binaryConverter(p, n);
        //     p = "Binary";
        //     System.out.println(decimal + "why");
        //     System.out.println(p);
        //     System.out.print(hexConverter(p, decimal));
        // }
        // System.out.println(hexa + "test");
        return hexa;
    }

    // One's Complement
    public static String onesComp(String n) {
        String flip = "";
        //System.out.println(n);

        for(int i = 1; i < n.length()+1; i++) {
            if(n.substring(n.length()-i, n.length()-(i-1)).equals("1")) {
                flip = "0".concat(flip);
            }
            else {
                flip = "1".concat(flip);
            }
        }
        //System.out.println(flip);
        return flip;
    }
    
    // Two's Complement
    public static String twosComp(String n) {
        n = onesComp(n);
        
    //System.out.println(n + "preTest");
        int counterr = n.length()-1;
        int subString = 1;
        String newN = "";
        //System.out.println(n.substring(n.length()-1));
        if(n.substring(n.length()-1).equals("1")) {
            newN = (n.substring(n.length()-(subString+1), n.length()-subString)).replaceAll(n.substring(n.length()-1), "0").concat(newN);
            while (counterr>0) {
                //System.out.println(n.substring(n.length()-(subString+1), n.length()-subString) + "testing!");
                if(n.substring(n.length()-(subString+1), n.length()-subString).equals("1")) {
                    newN = (n.substring(n.length()-(subString+1), n.length()-subString)).replaceAll(n.substring(n.length()-(subString+1), n.length()-subString), "0").concat(newN);
                    counterr--;
                }
                if(n.substring(n.length()-(subString+1), n.length()-subString).equals("0")) {
                    newN = (n.substring(n.length()-(subString+1), n.length()-subString)).replaceAll(n.substring(n.length()-(subString+1), n.length()-subString), "1").concat(newN);
                    counterr = 0;
                }
                subString++;
            }
        }
        if(n.substring(n.length()-1).equals("0")) {
            newN = (n.substring(n.length()-(subString+1), n.length()-subString)).replaceAll(n.substring(n.length()-(subString+1), n.length()-subString), "1").concat(newN);
        }
        //System.out.println(newN + "new");
        
        int newSize = newN.length();
        n = n.substring(0, n.length()-newSize);
        //System.out.println(n + "cut");
        n = n.concat(newN);
        //System.out.println(n + "final");

         return n;
    }

    // Task Seven Methods:

    // And Method
    public static String and(String n1, String n2, String n3) {
        String newNum = "";
        int size1 = n1.length();
        int size2 = n2.length();
        int size3 = n3.length();
        int adjuster = 0;
 
        if((size1 >= size2) && (size1>=size3)) {
            adjuster = size1-size2;
            for(int i = 0; i<adjuster; i++) {
                n2 = "0".concat(n2);
            }
            adjuster = size1-size3;
            for(int i = 0; i<adjuster; i++) {
                n3 = "0".concat(n3);
            }
        }
        else if ((size2>=size1) && (size2>=size3)) {
            adjuster = size2-size1;
            for(int i = 0; i<adjuster; i++) {
                n1 = "0".concat(n1);
            }
            adjuster = size2-size3;
            for(int i = 0; i<adjuster; i++) {
                n3 = "0".concat(n3);
            }
        }
        else {
            adjuster = size3-size1;
            for(int i = 0; i<adjuster; i++) {
                n1 = "0".concat(n1);
            }
            adjuster = size3-size2;
            for(int i = 0; i<adjuster; i++) {
                n2 = "0".concat(n2);
            }
        }
        for(int i = 0; i < n1.length(); i++) {
            if( (n1.substring(i, i+1).equals("1")) && (n2.substring(i, i+1).equals("1")) && (n3.substring(i, i+1).equals("1")) ) {
                newNum = newNum.concat("1");
            }
            else{
                newNum = newNum.concat("0");
            }
        }

        // System.out.println(n1);
        // System.out.println(n2);
        // System.out.println(n3);
         return newNum;
    } 

    // Or Method 
    public static String or(String n1, String n2, String n3) {
        String newNum = "";
        int size1 = n1.length();
        int size2 = n2.length();
        int size3 = n3.length();
        int adjuster = 0;
 
        if((size1 >= size2) && (size1>=size3)) {
            adjuster = size1-size2;
            for(int i = 0; i<adjuster; i++) {
                n2 = "0".concat(n2);
            }
            adjuster = size1-size3;
            for(int i = 0; i<adjuster; i++) {
                n3 = "0".concat(n3);
            }
        }
        else if ((size2>=size1) && (size2>=size3)) {
            adjuster = size2-size1;
            for(int i = 0; i<adjuster; i++) {
                n1 = "0".concat(n1);
            }
            adjuster = size2-size3;
            for(int i = 0; i<adjuster; i++) {
                n3 = "0".concat(n3);
            }
        }
        else {
            adjuster = size3-size1;
            for(int i = 0; i<adjuster; i++) {
                n1 = "0".concat(n1);
            }
            adjuster = size3-size2;
            for(int i = 0; i<adjuster; i++) {
                n2 = "0".concat(n2);
            }
        }
        for(int i = 0; i < n1.length(); i++) {
            if( (n1.substring(i, i+1).equals("1")) || (n2.substring(i, i+1).equals("1")) || (n3.substring(i, i+1).equals("1")) ) {
                newNum = newNum.concat("1");
            }
            else{
                newNum = newNum.concat("0");
            }
        }

        // System.out.println(n1);
        // System.out.println(n2);
        // System.out.println(n3);
         return newNum;
    }

    // Xor Method 
    public static String xor(String n1, String n2, String n3) {
        String newNum = "";
        int size1 = n1.length();
        int size2 = n2.length();
        int size3 = n3.length();
        int adjuster = 0;
 
        if((size1 >= size2) && (size1>=size3)) {
            adjuster = size1-size2;
            for(int i = 0; i<adjuster; i++) {
                n2 = "0".concat(n2);
            }
            adjuster = size1-size3;
            for(int i = 0; i<adjuster; i++) {
                n3 = "0".concat(n3);
            }
        }
        else if ((size2>=size1) && (size2>=size3)) {
            adjuster = size2-size1;
            for(int i = 0; i<adjuster; i++) {
                n1 = "0".concat(n1);
            }
            adjuster = size2-size3;
            for(int i = 0; i<adjuster; i++) {
                n3 = "0".concat(n3);
            }
        }
        else {
            adjuster = size3-size1;
            for(int i = 0; i<adjuster; i++) {
                n1 = "0".concat(n1);
            }
            adjuster = size3-size2;
            for(int i = 0; i<adjuster; i++) {
                n2 = "0".concat(n2);
            }
        }
        for(int i = 0; i < n1.length(); i++) {
            if( (n1.substring(i, i+1).equals("1")) && (n2.substring(i, i+1).equals("1")) && (n3.substring(i, i+1).equals("0")) ) {
                newNum = newNum.concat("0");
                //System.out.println("one");
            }
            else if( (n1.substring(i, i+1).equals("0")) && (n2.substring(i, i+1).equals("1")) && (n3.substring(i, i+1).equals("1")) ) {
                newNum = newNum.concat("0");
                //System.out.println("two");
            }
            else if( (n1.substring(i, i+1).equals("1")) && (n2.substring(i, i+1).equals("0")) && (n3.substring(i, i+1).equals("1")) ) {
                newNum = newNum.concat("0");
                //System.out.println("three");
            }
            else if( (n1.substring(i, i+1).equals("0")) && (n2.substring(i, i+1).equals("0")) && (n3.substring(i, i+1).equals("0")) ) {
                newNum = newNum.concat("0");
                //System.out.println("three");
            }
            else{
                newNum = newNum.concat("1");
                //System.out.println("else");
            }
        }

        //  System.out.println(n1);
        //  System.out.println(n2);
        //  System.out.println(n3);
         return newNum;
    }

    //Task Eight Methods:

    // 2 to the Left
    public static String twoLeft(String n) {
        n = n.concat("0");
        n = n.concat("0");

        return n;
    }

    // 2 to the Right
    public static String twoRight(String n) {
        n = n.substring(0, n.length()-2);
        return n;
    }

   
    public static void main(String[] args) {
         // task one
         if(args.length != 3) {
            System.out.println("Task 1");
            System.out.println("Incorrect number of arguments have been provided. Program Terminating!");
            System.exit(0);
         }
         else {
            System.out.println("Task 1");
            System.out.println("Correct number of arguments given.");
         }

        String argsOne = args[0];
        String argsTwo = args[1];
        String argsThree = args[2];
        if(argsOne.equals("a")) {
            System.out.println();
            System.out.println("Task 2");
            System.out.println("a=Decimal");
            System.out.println("b=Decimal");
            System.out.println("c=Decimal");
            System.out.println();
            System.out.println("Task 3");
            System.out.println("a=false");
            System.exit(0);
        }
        // String argsOne = "15";
        // String argsTwo = "0xfa";
        // String argsThree = "0b1111";
        String argOne = "", argTwo = "", argThree = "";
         String arg1 = "", arg2 = "", arg3 = "";

         //Manual paring
        if(argsOne.length()>1) {
            if(argsOne.substring(1,2).contains("x")) {
                argThree = argsOne;
            }
            else if(argsOne.substring(1,2).contains("b")) {
                argTwo = argsOne;
            }
            else {
                argOne = argsOne;
            }
        }
        else {
            argOne = argsOne;
        }
        if(argsTwo.length()>1) {
            if(argsTwo.substring(1,2).contains("x")) {
                argThree = argsTwo;
            }
            else if(argsTwo.substring(1,2).contains("b")) {
                argTwo = argsTwo;
            }
            else {
                argOne = argsTwo;
            }
        }
        else {
            argOne = argsOne;
        }
        if(argsThree.length()>1) {
            if(argsThree.substring(1,2).contains("x")) {
                argThree = argsThree;
            }
            else if(argsThree.substring(1,2).contains("b")) {
                argTwo = argsThree;
            }
            else {
                argOne = argsThree;
            }
        }
        else {
            argOne = argsOne;
        }
        

        
         //task two
         String arg1P, arg2P, arg3P;
         if(argOne.length()>1) {
            arg1P = argOne.substring(0, 2);
         //System.out.println(arg1P);
         } 
         else {
            arg1P = argOne;
         }
         if(argTwo.length()>1) {
            arg2P = argTwo.substring(0, 2);
         //System.out.println(arg1P);
         } 
         else {
            arg2P = argTwo;
         }
         if(argThree.length()>1) {
            arg3P = argThree.substring(0, 2);
         //System.out.println(arg1P);
         } 
         else {
            arg3P = argThree;
         }
        //  arg2P = argTwo.substring(0, 2);
        //  //System.out.println(arg2P);
        //  arg3P = argThree.substring(0, 2);
        // // System.out.println(arg3P);
        System.out.println("Task 2");
        System.out.println(argOne + "=" + taskTwo(arg1P));
        System.out.println(argTwo + "=" + taskTwo(arg2P));
        System.out.println(argThree + "=" + taskTwo(arg3P));
        System.out.println();


        // getting rid of the string's prefixes
        if(argOne.startsWith("0")) {
            arg1 = argOne.substring(2, argOne.length());
            System.out.println(arg1);
        }
        else {
            arg1 = argOne;
        }
        if(argTwo.startsWith("0")) {
            arg2 = argTwo.substring(2, argTwo.length());
           // System.out.println(arg2);
        }
        else {
            arg2 = argTwo;
        }
        if(argThree.startsWith("0")) {
            arg3 = argThree.substring(2, argThree.length());
           // System.out.println(arg3);
        }
        else {
            arg3 = argThree;
        }
 
         //task three
         System.out.println("Task 3");
         String taskarg1 = args[0];
         String taskarg2 = args[1];
         String taskarg3 = args[2];
         String task1 = "";
         String task2 = "";
         String task3 = "";
         String task1P, task2P, task3P;
         
         // getting rid of the string's prefixes
        if(taskarg1.startsWith("0")) {
            task1 = taskarg1.substring(2, taskarg1.length());
            //System.out.println(arg1);
        }
        else {
            task1 = taskarg1;
        }
        if(taskarg2.startsWith("0")) {
            task2 = taskarg2.substring(2, taskarg2.length());
           // System.out.println(arg2);
        }
        else {
            task2 = taskarg2;
        }
        if(taskarg3.startsWith("0")) {
            task3 = taskarg3.substring(2, taskarg3.length());
           // System.out.println(arg3);
        }
        else {
            task3 = taskarg3;
        }

        if(taskarg1.length() >1) {
            task1P = taskarg1.substring(0, 2);
         //System.out.println(arg1P);
        }
        else {
            task1P = taskarg1;
        }
        if(taskarg2.length() >1) {
            task2P = taskarg2.substring(0, 2);
         //System.out.println(arg1P);
        }
        else {
            task2P = taskarg2;
        }
        if(taskarg3.length() >1) {
            task3P = taskarg3.substring(0, 2);
         //System.out.println(arg1P);
        }
        else {
            task3P = taskarg3;
        }
        // task1P = taskarg1.substring(0, 2);
        //  //System.out.println(arg1P);
        //  task2P = taskarg2.substring(0, 2);
        //  //System.out.println(arg2P);
        //  task3P = taskarg3.substring(0, 2);

         Boolean value1 = errorChecker(task1P, task1);
         //System.out.println(value1);
         if (value1 == true) {
            System.out.println(task1P + task1 + "=true");
         }
         Boolean value2 = errorChecker(task2P, task2);
         //System.out.println(value2);
         if (value2 == true) {
            System.out.println(task1P + task1 + "=true");
         }
         Boolean value3 = errorChecker(task3P, task3);
         //System.out.println(value3);
         if (value3 == true) {
            System.out.println(task3P + task3 + "=true");
         }
         if ((value1 == false) || (value2 == false) || (value3 == false))  {
            //System.out.println("Why are you not exiting?");
            System.exit(0);
         }

         //task four
         System.out.println("Task 4");
         System.out.println("Start = " + arg2P + arg2 + ", Decimal = " + decimalConverter(arg2P, arg2));
         System.out.println("Start = " + arg3P + arg3 + ", Decimal = " + decimalConverter(arg3P, arg3));
         System.out.println("Start = " + arg1 + ", Binary = " + binaryConverter(arg1P, arg1));
         System.out.println("Start = " + arg3P + arg3 + ", Binary = " + binaryConverter(arg3P, arg3));
         System.out.println("Start = " + arg1 + ", Hexadecimal = " + hexConverter(arg2P, binaryConverter(arg1P, arg1)));
         System.out.println("Start = " + arg2P + arg2 + ", Hexadecimal = " + hexConverter(arg2P, arg2));
         System.out.println();

         //task five
         String binary1 = binaryConverter(arg1P, arg1);
         String binary2 = arg2;
         String binary3 = binaryConverter(arg3P, arg3);
         
         System.out.println("Task 5");
         System.out.println(arg1 + "=" + binary1 + "=>" + onesComp(binary1));
         System.out.println(arg2P + arg2 + "=" + binary2 + "=>" + onesComp(binary2));
         System.out.println(arg3P + arg3 + "=" + binary3 + "=>" + onesComp(binary3));
         System.out.println();
        
         //task six
         System.out.println("Task 6");
         System.out.println(arg1 + "=" + binary1 + "=>" + twosComp(binary1));
         System.out.println(arg2P + arg2 + "=" + binary2 + "=>" + twosComp(binary2));
         System.out.println(arg3P + arg3 + "=" + binary3 + "=>" + twosComp(binary3));
         System.out.println();
 
         //task seven
         System.out.println("Task 7");
         System.out.println(binary1 + "|" + binary2 + "|" + binary3 + "=" + or(binary1, binary2, binary3));
         System.out.println(binary1 + "&" + binary2 + "&" + binary3 + "=" + and(binary1, binary2, binary3));
         System.out.println(binary1 + "^" + binary2 + "^" + binary3 + "=" + xor(binary1, binary2, binary3));
         System.out.println();
 
         //task eight
         System.out.println("Task 8");
         System.out.println(binary1 + "<<2=" + twoLeft(binary1) + "," + binary1 + ">>2=" + twoRight(binary1));
         System.out.println(binary2 + "<<2=" + twoLeft(binary2) + "," + binary2 + ">>2=" + twoRight(binary2));
         System.out.println(binary3 + "<<2=" + twoLeft(binary3) + "," + binary3 + ">>2=" + twoRight(binary3));
        //  System.out.println(binary1 + ">>2=" + twoRight(binary1));
        //  System.out.println(binary2 + ">>2=" + twoRight(binary2));
        //  System.out.println(binary3 + ">>2=" + twoRight(binary3));
         System.out.println();
     }
}
