package cs250.hw3;
import java.io.*;    
import java.net.*;
import java.util.Random;

public class TCPClient {
    static DataInputStream din;
    static DataOutputStream dout;
    static Socket clientSocket;

    //receiving method
    public static int receiveNum(){
        try {
            int response = din.readInt(); // Reads an int from the input stream 
            return response;
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return -1; // if an incorrect value is read, the EXIT_NUM will be returned
    }

    //sending method
    public static void sendNumber(int numToSend){
        try {
            dout.writeInt(numToSend); // Writes an int to the output stream
            dout.flush(); // By flushing the stream, it means to clear the stream of any element that may be or maybe not inside the stream
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }
    
    public static void main(String[] args){
        final int port =  Integer.parseInt(args[1]);
        final String server_ip = args[0]; 

        try{
            // Initialize Necessary Objects
            clientSocket = new Socket(server_ip, port); // Establishes a connection to the server
            dout = new DataOutputStream(clientSocket.getOutputStream());
            din = new DataInputStream(clientSocket.getInputStream());
                  
            System.out.println("Received config");
             
            //receives message
            int response = receiveNum();
            int response2 = receiveNum();

            //prints message
            System.out.println("number of messages = " + response);
            System.out.println("seed = " + response2);


            //send messages to server & wait ten seconds 

            Random ranNum = new Random(response2);
            long sum = 0;
            for(int i = 0; i < response; i++) {
                int random = ranNum.nextInt();
                sendNumber(random);
                sum = sum + random;
            }

            //print sent messages for part 2
            System.out.println("Starting to send messages to server...");
            System.out.println("Finished sending messages to server.");
            System.out.println("Total messages sent: " + response);
            System.out.println("Sum of messages sent: " + sum);

            long sum2 = 0;
            for(int i = 0; i < response; i++) {
                int response1 = receiveNum();
                sum2 = sum2 + response1;
            }
            //print messages for part 3
            System.out.println("Starting to listen for messages from server...");
            System.out.println("Finished listening for messages from server.");
            System.out.println("Total messages received: " + response);
            System.out.println("Sum of messages received: " + sum2);
        }
        catch(IOException e){
            System.err.println(e.getMessage());
        }
    }
}