package cs250.hw3;
import java.io.*;    
import java.net.*;
import java.util.Random;

public class TCPServer {
    static DataInputStream din1;
    static DataInputStream din2;
    static DataOutputStream dout1;
    static DataOutputStream dout2;
    static Socket clientSocket;
    static Socket clientSocket2;
    static ServerSocket serverSocket;

    //receiving method
    public static int receiveNum(DataInputStream din){
        try {
            int response = din.readInt();
            return response;
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return -1;
    }

    //sending method
    public static void sendNumber(DataOutputStream dout, int numToSend){
        try {
            dout.writeInt(numToSend);
            dout.flush(); // By flushing the stream, it means to clear the stream of any element that may be or maybe not inside the stream
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }

    }

    //closing method
    public static void cleanUp(){
        try {
            serverSocket.close();
            clientSocket.close();
            clientSocket2.close();
            dout1.close();
            dout2.close();
            din1.close();
            din2.close();

            //System.out.println("Connections Closed");
            System.exit(0);

        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }


    public static void main(String[] args){
        int port = Integer.parseInt(args[0]);
        int seed = Integer.parseInt(args[1]);
        int numMessages = Integer.parseInt(args[2]);
    
        try{
            System.out.println("IP Address: " + InetAddress.getLocalHost() + "\nPort Number " + port);  

            // Initialize Necessary Objects
            serverSocket = new ServerSocket(port);
            System.out.println("waiting for client...");
            clientSocket = serverSocket.accept();

            dout1 = new DataOutputStream(clientSocket.getOutputStream());
            din1 = new DataInputStream(clientSocket.getInputStream());

            clientSocket2 = serverSocket.accept();
            dout2 = new DataOutputStream(clientSocket2.getOutputStream());
            din2 = new DataInputStream(clientSocket2.getInputStream());

            System.out.println("Clients Connected!");
            System.out.println("Sending config to clients...");

            //make the random numbers for each client
            Random ranNum = new Random(seed);
            int ranc1 = ranNum.nextInt();
            int ranc2 = ranNum.nextInt();
        
            //send messages
            sendNumber(dout1, numMessages);
            sendNumber(dout1, ranc1);
            sendNumber(dout2, numMessages);
            sendNumber(dout2, ranc2);
            System.out.println(clientSocket.getInetAddress().getHostName() + " " + ranc1);
            System.out.println(clientSocket2.getInetAddress().getHostName() + " " + ranc2);

            System.out.println("Finished sending config to clients.");
            System.out.println("Starting to listen for client messages...");

            //receive messages 
            long sumC1 = 0;
            long sumC2 = 0;
            for(int i = 0; i < numMessages; i++) {
                int response = receiveNum(din1);
                sendNumber(dout2, response);
                sumC1 = sumC1 + response;
            }
            for(int i = 0; i < numMessages; i++) {
                int response = receiveNum(din2);
                sendNumber(dout1, response);
                sumC2 = sumC2 + response;
            }
            System.out.println("Finished listening for client messages.");
            
            //client one message
            System.out.println(clientSocket.getInetAddress().getHostName());
            System.out.println("    " + "Messages received: " + numMessages);
            System.out.println("    " + "Sum received: " + sumC1);

            //client two message
            System.out.println(clientSocket2.getInetAddress().getHostName());
            System.out.println("    " + "Messages received: " + numMessages);
            System.out.println("    " + "Sum received: " + sumC2);

            //close connection
            cleanUp();
        }
        catch(IOException e){
            System.err.println(e.getMessage());
        }
    }
}